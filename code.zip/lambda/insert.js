import { DynamoDBClient } from "@aws-sdk/client-dynamodb";
import { BatchWriteCommand, DynamoDBDocumentClient } from "@aws-sdk/lib-dynamodb";

const client = new DynamoDBClient({});
const ddbDocClient = DynamoDBDocumentClient.from(client);

const defaultTickets = [
  {
    "from_time": "2025-07-08T02:30:00Z",  // 08:00 IST
    "to_time": "2025-07-08T04:30:00Z",    // 10:00 IST
    "standard_price": 150,
    "plus_price": 200
  },
  {
    "from_time": "2025-07-08T09:00:00Z",  // 14:30 IST
    "to_time": "2025-07-08T10:30:00Z",    // 16:00 IST
    "standard_price": 160,
    "plus_price": 215
  },
  {
    "from_time": "2025-07-09T04:30:00Z",  // 10:00 IST
    "to_time": "2025-07-09T06:30:00Z",    // 12:00 IST
    "standard_price": 170,
    "plus_price": 230
  },
  {
    "from_time": "2025-07-10T12:30:00Z",  // 18:00 IST
    "to_time": "2025-07-10T14:30:00Z",    // 20:00 IST
    "standard_price": 180,
    "plus_price": 250
  },
  {
    "from_time": "2025-07-11T03:30:00Z",  // 09:00 IST
    "to_time": "2025-07-11T05:30:00Z",    // 11:00 IST
    "standard_price": 165,
    "plus_price": 220
  },
  {
    "from_time": "2025-07-12T09:30:00Z",  // 15:00 IST
    "to_time": "2025-07-12T11:00:00Z",    // 16:30 IST
    "standard_price": 185,
    "plus_price": 255
  },
  {
    "from_time": "2025-07-13T07:30:00Z",  // 13:00 IST
    "to_time": "2025-07-13T09:30:00Z",    // 15:00 IST
    "standard_price": 190,
    "plus_price": 260
  },
  {
    "from_time": "2025-07-14T10:30:00Z",  // 16:00 IST
    "to_time": "2025-07-14T12:30:00Z",    // 18:00 IST
    "standard_price": 195,
    "plus_price": 270
  },
  {
    "from_time": "2025-07-15T06:00:00Z",  // 11:30 IST
    "to_time": "2025-07-15T07:30:00Z",    // 13:00 IST
    "standard_price": 200,
    "plus_price": 280
  },
  {
    "from_time": "2025-07-16T11:30:00Z",  // 17:00 IST
    "to_time": "2025-07-16T14:00:00Z",    // 19:30 IST
    "standard_price": 210,
    "plus_price": 295
  }
]


export const handler = async () => {
  const putRequests = defaultTickets.map((item) => ({
    PutRequest: {
      Item: {
        id: `${item.from_time}_${item.to_time}`,
        ...item,
      },
    },
  }));

  const command = new BatchWriteCommand({
    RequestItems: {
      available_tickets: putRequests,
    },
  });

  try {
    await ddbDocClient.send(command);
    return {
      statusCode: 200,
      body: JSON.stringify({
        message: "Default tickets inserted successfully.",
        insertedCount: defaultTickets.length,
      }),
    };
  } catch (error) {
    console.error("Error inserting tickets:", error);
    return {
      statusCode: 500,
      body: JSON.stringify({
        message: "Failed to insert tickets.",
        error: error.message,
      }),
    };
  }
};





















import { DynamoDBClient } from "@aws-sdk/client-dynamodb";
import { BatchWriteCommand, DynamoDBDocumentClient } from "@aws-sdk/lib-dynamodb";

const client = new DynamoDBClient({});
const ddbDocClient = DynamoDBDocumentClient.from(client);

const defaultTickets = [
  { from_time: "2025-07-14T02:00:00Z", to_time: "2025-07-14T04:00:00Z", standard_price: 220, plus_price: 280, location: "London", date: "2025-07-14" },
  { from_time: "2025-07-14T06:30:00Z", to_time: "2025-07-14T08:30:00Z", standard_price: 225, plus_price: 285, location: "London", date: "2025-07-14" },
  { from_time: "2025-07-14T10:00:00Z", to_time: "2025-07-14T12:00:00Z", standard_price: 230, plus_price: 290, location: "London", date: "2025-07-14" },
  { from_time: "2025-07-14T15:30:00Z", to_time: "2025-07-14T17:30:00Z", standard_price: 235, plus_price: 295, location: "London", date: "2025-07-14" },

  { from_time: "2025-07-15T03:00:00Z", to_time: "2025-07-15T05:00:00Z", standard_price: 225, plus_price: 285, location: "London", date: "2025-07-15" },
  { from_time: "2025-07-15T06:45:00Z", to_time: "2025-07-15T08:45:00Z", standard_price: 230, plus_price: 290, location: "London", date: "2025-07-15" },
  { from_time: "2025-07-15T11:30:00Z", to_time: "2025-07-15T13:30:00Z", standard_price: 235, plus_price: 295, location: "London", date: "2025-07-15" },
  { from_time: "2025-07-15T18:00:00Z", to_time: "2025-07-15T20:00:00Z", standard_price: 240, plus_price: 300, location: "London", date: "2025-07-15" },

  { from_time: "2025-07-16T01:00:00Z", to_time: "2025-07-16T03:00:00Z", standard_price: 230, plus_price: 290, location: "London", date: "2025-07-16" },
  { from_time: "2025-07-16T05:30:00Z", to_time: "2025-07-16T07:30:00Z", standard_price: 235, plus_price: 295, location: "London", date: "2025-07-16" },
  { from_time: "2025-07-16T09:45:00Z", to_time: "2025-07-16T11:45:00Z", standard_price: 240, plus_price: 300, location: "London", date: "2025-07-16" },
  { from_time: "2025-07-16T16:00:00Z", to_time: "2025-07-16T18:00:00Z", standard_price: 245, plus_price: 305, location: "London", date: "2025-07-16" },

  { from_time: "2025-07-17T02:15:00Z", to_time: "2025-07-17T04:15:00Z", standard_price: 235, plus_price: 295, location: "London", date: "2025-07-17" },
  { from_time: "2025-07-17T07:00:00Z", to_time: "2025-07-17T09:00:00Z", standard_price: 240, plus_price: 300, location: "London", date: "2025-07-17" },
  { from_time: "2025-07-17T11:30:00Z", to_time: "2025-07-17T13:30:00Z", standard_price: 245, plus_price: 305, location: "London", date: "2025-07-17" },
  { from_time: "2025-07-17T17:45:00Z", to_time: "2025-07-17T19:45:00Z", standard_price: 250, plus_price: 310, location: "London", date: "2025-07-17" },
{ from_time: "2025-07-14T06:00:00Z", to_time: "2025-07-14T08:00:00Z", standard_price: 220, plus_price: 270, location: "Paris", date: "2025-07-14" },
{ from_time: "2025-07-14T10:30:00Z", to_time: "2025-07-14T12:30:00Z", standard_price: 225, plus_price: 275, location: "Paris", date: "2025-07-14" },
{ from_time: "2025-07-14T14:00:00Z", to_time: "2025-07-14T16:00:00Z", standard_price: 230, plus_price: 280, location: "Paris", date: "2025-07-14" },
{ from_time: "2025-07-14T18:30:00Z", to_time: "2025-07-14T20:30:00Z", standard_price: 235, plus_price: 285, location: "Paris", date: "2025-07-14" },

{ from_time: "2025-07-15T05:00:00Z", to_time: "2025-07-15T07:00:00Z", standard_price: 220, plus_price: 270, location: "Paris", date: "2025-07-15" },
{ from_time: "2025-07-15T09:30:00Z", to_time: "2025-07-15T11:30:00Z", standard_price: 225, plus_price: 275, location: "Paris", date: "2025-07-15" },
{ from_time: "2025-07-15T13:00:00Z", to_time: "2025-07-15T15:00:00Z", standard_price: 230, plus_price: 280, location: "Paris", date: "2025-07-15" },

{ from_time: "2025-07-16T04:30:00Z", to_time: "2025-07-16T06:30:00Z", standard_price: 220, plus_price: 270, location: "Paris", date: "2025-07-16" },
{ from_time: "2025-07-16T11:00:00Z", to_time: "2025-07-16T13:00:00Z", standard_price: 225, plus_price: 275, location: "Paris", date: "2025-07-16" },
{ from_time: "2025-07-16T16:30:00Z", to_time: "2025-07-16T18:30:00Z", standard_price: 235, plus_price: 285, location: "Paris", date: "2025-07-16" },

{ from_time: "2025-07-17T03:00:00Z", to_time: "2025-07-17T05:00:00Z", standard_price: 220, plus_price: 270, location: "Paris", date: "2025-07-17" },
{ from_time: "2025-07-17T08:30:00Z", to_time: "2025-07-17T10:30:00Z", standard_price: 225, plus_price: 275, location: "Paris", date: "2025-07-17" },
{ from_time: "2025-07-17T12:30:00Z", to_time: "2025-07-17T14:30:00Z", standard_price: 230, plus_price: 280, location: "Paris", date: "2025-07-17" },
{ from_time: "2025-07-17T19:00:00Z", to_time: "2025-07-17T21:00:00Z", standard_price: 235, plus_price: 285, location: "Paris", date: "2025-07-17" },


];


export const handler1 = async () => {
  const putRequests = defaultTickets.map((item) => ({
    PutRequest: {
      Item: {
        id: `${item.from_time}_${item.to_time}`,
        ...item,
      },
    },
  }));

  const command = new BatchWriteCommand({
    RequestItems: {
      available_tickets: putRequests,
    },
  });

  try {
    await ddbDocClient.send(command);
    return {
      statusCode: 200,
      body: JSON.stringify({
        message: "Default tickets inserted successfully.",
        insertedCount: defaultTickets.length,
      }),
    };
  } catch (error) {
    console.error("Error inserting tickets:", error);
    return {
      statusCode: 500,
      body: JSON.stringify({
        message: "Failed to insert tickets.",
        error: error.message,
      }),
    };
  }
};
