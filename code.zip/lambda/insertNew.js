import { DynamoDBClient } from "@aws-sdk/client-dynamodb";
import {
  BatchWriteCommand,
  DynamoDBDocumentClient,
} from "@aws-sdk/lib-dynamodb";

const client = new DynamoDBClient({});
const ddbDocClient = DynamoDBDocumentClient.from(client);

// Helper to format YYYY-MM-DD
function formatDate(date) {
  return date.toISOString().split("T")[0];
}

// Helper to generate ISO time from a date with offset in hours
function getISOTime(baseDate, hourOffset = 0, minuteOffset = 0) {
  const newDate = new Date(baseDate);
  newDate.setHours(newDate.getHours() + hourOffset);
  newDate.setMinutes(newDate.getMinutes() + minuteOffset);
  return newDate.toISOString();
}

// Generate tickets for from → to for next X days
function generateTickets(from, to, startDate, count) {
  const tickets = [];
  for (let i = 0; i < count; i++) {
    const base = new Date(startDate);
    base.setDate(base.getDate() + i);

    const date = formatDate(base);
    const from_time = getISOTime(base, 6, i * 30); // Starting 6AM, staggered 30 mins
    const to_time = getISOTime(new Date(from_time), 2); // +2 hours

    const standard_price = 150 + i * 10;
    const plus_price = standard_price + 50;

    tickets.push({
      route_date: `${from}#${to}#${date}`,
      from,
      to,
      date,
      from_time,
      to_time,
      standard_price,
      plus_price,
    });
  }
  return tickets;
}

const defaultTickets = [
  ...generateTickets("Chennai", "Bangalore", "2025-07-14", 4),
  ...generateTickets("London", "Paris", "2025-07-14", 5),
  ...generateTickets("Paris", "London", "2025-07-14", 3),
];

export const handler = async () => {
  const batchSize = 25;
  const chunks = [];

  for (let i = 0; i < defaultTickets.length; i += batchSize) {
    const chunk = defaultTickets.slice(i, i + batchSize).map((item) => ({
      PutRequest: {
        Item: {
          id: `${item.route_date}_${item.from_time}`,
          ...item,
        },
      },
    }));
    chunks.push(chunk);
  }

  try {
    for (const putRequests of chunks) {
      const command = new BatchWriteCommand({
        RequestItems: {
          ticket_routes: putRequests,
        },
      });
      await ddbDocClient.send(command);
    }

    return {
      statusCode: 200,
      body: JSON.stringify({
        message: "Tickets inserted successfully.",
        insertedCount: defaultTickets.length,
      }),
    };
  } catch (error) {
    console.error("Error inserting tickets:", error);
    return {
      statusCode: 500,
      body: JSON.stringify({
        message: "Failed to insert tickets.",
        error: error.message,
      }),
    };
  }
};
